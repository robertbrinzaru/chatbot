const { Configuration, OpenAIApi } = require('openai');

const configuration = new Configuration({
  apiKey: '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',
});

const openai = new OpenAIApi(configuration);

module.exports = { openai };
