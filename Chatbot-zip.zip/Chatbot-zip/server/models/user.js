// Import required modules
const mongoose = require("mongoose"); // Mongoose for MongoDB interaction
const jwt = require("jsonwebtoken"); // JSON Web Token for authentication
const Joi = require("joi"); // Joi for input validation
const passwordComplexity = require("joi-password-complexity"); // Joi plugin for password complexity validation

// Define user schema
const userSchema = new mongoose.Schema({
    firstName: { type: String, required: true }, // First name of the user
    lastName: { type: String, required: true }, // Last name of the user
    email: { type: String, required: true }, // Email of the user
    password: { type: String, required: true }, // Password of the user
    admin: { type: Boolean, required: true, default: false }, // Boolean flag indicating if the user is an admin
});

// Method to generate authentication token for user
userSchema.methods.generateAuthToken = function () {
    // Generate a JWT token with the user's ID and expiration time of 7 days
    const token = jwt.sign({ _id: this._id }, process.env.JWTPRIVATEKEY, {
        expiresIn: "7d",
    });
    return token;
};

// Create User model from user schema
const User = mongoose.model("user", userSchema);

// Function to validate user input using Joi schema
const validate = (data) => {
    // Define Joi schema for user input validation
    const schema = Joi.object({
        firstName: Joi.string().required().label("First Name"), // First name validation
        lastName: Joi.string().required().label("Last Name"), // Last name validation
        email: Joi.string().email().required().label("Email"), // Email validation
        password: passwordComplexity().required().label("Password"), // Password validation with complexity requirements
    });
    // Validate input data against the schema and return the result
    return schema.validate(data);
};

// Export User model and validate function
module.exports = { User, validate };
