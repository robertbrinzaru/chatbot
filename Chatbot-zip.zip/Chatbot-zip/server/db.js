// Import the mongoose library for MongoDB interaction
const mongoose = require("mongoose");

// Export a function to establish a database connection
module.exports = () => {
    // Define connection parameters
    const connectionParams = {
        useNewUrlParser: true, // Use the new URL parser
        useUnifiedTopology: true, // Use the new Server Discovery and Monitoring engine
    };

    try {
        // Attempt to connect to the MongoDB database using the connection parameters and the URI stored in the environment variable DB
        mongoose.connect(process.env.DB, connectionParams);

        // Log a success message if the connection is established
        console.log("Connected to database successfully");
    } catch (error) {
        // Log an error message if the connection fails and output the error
        console.log("Could not connect to database!");
        console.log(error);
    }
};
