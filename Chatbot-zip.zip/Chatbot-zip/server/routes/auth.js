// Import the express module and create a router
const router = require("express").Router();

// Import the User model from the models/user file
const { User } = require("../models/user");

// Import the bcrypt library for password hashing
const bcrypt = require("bcrypt");

// Import the Joi library for input validation
const Joi = require("joi");

// Route to handle user login
router.post("/", async (req, res) => {
    try {
        // Validate the request body using the validate function
        const { error } = validate(req.body);
        
        // If there's an error in validation, return a 400 Bad Request response
        if (error)
            return res.status(400).send({ message: error.details[0].message });

        // Find the user in the database by email
        const user = await User.findOne({ email: req.body.email });
        
        // If the user doesn't exist, return a 401 Unauthorized response
        if (!user)
            return res.status(401).send({ message: "Invalid Email or Password" });

        // Compare the password provided in the request with the hashed password stored in the database
        const validPassword = await bcrypt.compare(req.body.password, user.password);
        
        // If the password is invalid, return a 401 Unauthorized response
        if (!validPassword)
            return res.status(401).send({ message: "Invalid Email or Password" });

        // Generate an authentication token for the user
        const token = user.generateAuthToken();

        // Prepare response data
        const data = {
            token,
            user,
            message: "Logged in successfully"
        };

        // Send a 200 OK response with the response data
        res.status(200).send({ data });
    } catch (error) {
        // If an error occurs, send a 500 Internal Server Error response
        res.status(500).send({ message: "Internal Server Error" });
    }
});

// Function to validate user input using Joi schema
const validate = (data) => {
    const schema = Joi.object({
        email: Joi.string().email().required().label("Email"),
        password: Joi.string().required().label("Password"),
    });
    return schema.validate(data);
};

// Export the router
module.exports = router;
