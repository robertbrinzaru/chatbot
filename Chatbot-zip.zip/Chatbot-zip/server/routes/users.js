// Import the express module and create a router
const router = require("express").Router();

// Import the User model and validation function from the models/user file
const { User, validate } = require("../models/user");

// Import the bcrypt library for password hashing
const bcrypt = require("bcrypt");

// Route to handle user registration
router.post("/", async (req, res) => {
    try {
        // Validate the request body using the validate function
        const { error } = validate(req.body);
        
        // If there's an error in validation, return a 400 Bad Request response
        if (error)
            return res.status(400).send({ message: error.details[0].message });

        // Check if a user with the same email already exists
        const user = await User.findOne({ email: req.body.email });
        
        // If a user with the same email exists, return a 409 Conflict response
        if (user)
            return res.status(409).send({ message: "User with given email already exists" });

        // Generate a salt for password hashing
        const salt = await bcrypt.genSalt(Number(process.env.SALT));
        
        // Hash the password using the generated salt
        const hashPassword = await bcrypt.hash(req.body.password, salt);

        // Create a new user with the hashed password and save it to the database
        await new User({ ...req.body, password: hashPassword }).save();
        
        // Return a 201 Created response
        res.status(201).send({ message: "User created successfully" });
    } catch (error) {
        // If an error occurs, return a 500 Internal Server Error response
        res.status(500).send({ message: "Internal Server Error" });
    }
});

// Route to get all users
router.get("/getusers", async (req, res) => {
    try {
        // Find all users in the database
        const users = await User.find();
        
        // Return a 200 OK response with the list of users
        res.status(200).send(users);
    } catch (error) {
        // If an error occurs, return a 500 Internal Server Error response
        console.error(error);
        res.status(500).send({ message: "Internal Server Error" });
    }
});

// Route to change user's role
router.put('/:id/changerole', async (req, res) => {
    try {
        // Extract user ID and admin role from request parameters and body
        const { id } = req.params;
        const { admin } = req.body;
        
        // Find the user by ID
        const user = await User.findById(id);
        
        // If the user is not found, return a 404 Not Found response
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        
        // Update the user's role
        user.admin = admin;
        await user.save();
        
        // Return a 200 OK response with the updated user object
        res.status(200).json({ message: 'User role changed successfully', user });
    } catch (error) {
        // If an error occurs, return a 500 Internal Server Error response
        console.error('Error changing user role:', error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

// Export the router
module.exports = router;
