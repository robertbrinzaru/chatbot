// Import the express module and create a router
const router = require("express").Router();

// Import the path module for working with file paths
const path = require('path');

// Import the fs module for file system operations
const fs = require("fs");

// Import helper functions
const { openai } = require("../utils/helper");
const generateEmbedding = require("../utils/embedding");

// Define the path to the file containing embedded data
let embeddedPath = "./embeddedData/embeddedFile.txt";

// Config Variables
let embeddingStore = {};

// Maximum tokens for OpenAI completion
const maxTokens = 100;

// Prefix for embedding store keys
const embeds_storage_prefix = "embeds:";

let embeddedQuestion;

// Function to create prompt for OpenAI completion
const createPrompt = (question, paragraph) => {
    return (
        "Answer the following question, also use your own knowledge when necessary :\n\n" +
        "Context :\n" +
        paragraph.join("\n\n") +
        "\n\nQuestion :\n" +
        question +
        "?" +
        "\n\nAnswer :"
    );
};

// Function to extract paragraph key from embedding store key
const keyExtractParagraph = (key) => {
    return key.substring(embeds_storage_prefix.length);
};

// Function to compare embeddings and calculate similarity score
const compareEmbeddings = (embedding1, embedding2) => {
    var length = Math.min(embedding1.length, embedding2.length);
    var dotprod = 0;

    for (var i = 0; i < length; i++) {
        dotprod += embedding1[i] * embedding2[i];
    }

    return dotprod;
};

// Function to find closest paragraphs based on similarity score
const findClosestParagraphs = (questionEmbedding, count) => {
    var items = [];

    for (const key in embeddingStore) {
        let paragraph = keyExtractParagraph(key);

        let currentEmbedding = JSON.parse(embeddingStore[key]).embedding;

        items.push({
            paragraph: paragraph,
            score: compareEmbeddings(questionEmbedding, currentEmbedding),
        });
    }

    items.sort(function (a, b) {
        return b.score - a.score;
    });

    return items.slice(0, count).map((item) => item.paragraph);
};

// Function to generate completion using OpenAI
const generateCompletion = async (prompt) => {
    try {
        // Retrieve embedding store and parse it
        let embeddingStoreJSON = fs.readFileSync(embeddedPath, {
            encoding: "utf-8",
            flag: "r",
        });

        embeddingStore = JSON.parse(embeddingStoreJSON);

        // Embed the prompt using embedding model
        let embeddedQuestionResponse = await openai.createEmbedding({
            input: prompt,
            model: "text-embedding-ada-002",
        });

        // Some error handling
        if (embeddedQuestionResponse.data.data.length) {
            embeddedQuestion = embeddedQuestionResponse.data.data[0].embedding;
        } else {
            throw Error("Question not embedded properly");
        }

        // Find the closest count(int) paragraphs
        let closestParagraphs = findClosestParagraphs(embeddedQuestion, 5); // Tweak this value for selecting paragraphs number

        // Generate completion using GPT-3.5
        let completionData = await openai.createChatCompletion({
            model: "gpt-3.5-turbo",
            messages: [
                {
                    role: "user",
                    content: createPrompt(prompt, closestParagraphs),
                },
            ],
            max_tokens: maxTokens,
            temperature: 0, // Tweak for more random answers
        });

        // Return the completed message
        if (!completionData.data.choices) {
            throw new Error("No answer gotten");
        }
        return completionData.data.choices[0].message.content.trim();
    } catch (error) {
        console.log(error);
        if (error.response) {
            console.error(error.response.status, error.response.data);
        } else {
            console.error(`Error with OpenAI API request: ${error.message}`);
        }
    }
};

// Route to generate completion for a given message
router.post('/getmessage', async (req, res) => {
    try {
        const message = generateCompletion(req?.body?.message);
        message.then(msg => res.status(200).json({ message: msg }))
    } catch (error) {
        console.error('Error changing user role:', error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

// Route to get data from a text file
router.get('/getfiledata', async (req, res) => {
    try {
        const data = fs.readFileSync('./sourceData/sourceFile.txt', 'utf8');
        res.status(200).json({ fileData: data })
    } catch (error) {
        console.error('Error changing user role:', error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

// Route to set data in a text file
router.post('/setfiledata', async (req, res) => {
    try {
        const updatedData = req.body?.fileData
        const filePath = './sourceData/sourceFile.txt'; // Path to the text file
        // Write the updated data to the text file
        fs.writeFileSync(filePath, updatedData, 'utf8');
        generateEmbedding().then(generated => {
            if (generated) {
                res.status(200).json({ success: true })
            } else {
                res.status(500).json({ error: 'something went wrong!' })
            }
        })
    } catch (error) {
        console.error('Error changing user role:', error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

// Export the router
module.exports = router;
