// Load environment variables from a .env file into process.env
require("dotenv").config();

// Import required modules
const express = require("express");
const app = express();
const cors = require("cors");
const connection = require("./db"); // Import database connection function
const userRoutes = require("./routes/users"); // Import user routes
const authRoutes = require("./routes/auth"); // Import authentication routes
const chatRoutes = require("./routes/openai"); // Import chat routes

// Establish database connection
connection();

// Middleware setup
app.use(express.json()); // Parse JSON bodies
app.use(cors()); // Enable Cross-Origin Resource Sharing

// Define routes
app.use("/api/users", userRoutes); // Set up user routes
app.use("/api/auth", authRoutes); // Set up authentication routes
app.use("/api/chat", chatRoutes); // Set up chat routes

// Set up server to listen for requests
const port = process.env.PORT || 8080; // Use the specified port or default to 8080
app.listen(port, console.log(`Listening on port ${port}...`)); // Start the server and log a message
