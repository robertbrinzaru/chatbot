import styles from "./styles.module.css";

const AppHeader = () => {
	const handleLogout = () => {
		localStorage.removeItem("user");
		window.location.reload();
	};

	return (
		<div className={styles.main_container}>
			<nav className={styles.navbar}>
				<h1>Chatbot</h1>
				<button className={styles.white_btn} onClick={handleLogout}>
					Logout
				</button>
			</nav>
		</div>
	);
};

export default AppHeader;
