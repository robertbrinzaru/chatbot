// Import necessary hooks and modules
import { useState } from "react"; // useState hook for state management
import axios from "axios"; // Axios for making HTTP requests
import { Link, useNavigate } from "react-router-dom"; // Link and useNavigate for navigation
import styles from "./styles.module.css"; // CSS module for styling

// Define the Signup component
const Signup = () => {
    // State variables for form data and error message
    const [data, setData] = useState({
        firstName: "",
        lastName: "",
        email: "",
        password: "",
    });
    const [error, setError] = useState(""); // State variable for error message

    // Use navigate hook for programmatic navigation
    const navigate = useNavigate();

    // Event handler to update state when input values change
    const handleChange = ({ currentTarget: input }) => {
        setData({ ...data, [input.name]: input.value });
    };

    // Event handler to submit the form data
    const handleSubmit = async (e) => {
        e.preventDefault(); // Prevent default form submission behavior
        try {
            const url = "http://localhost:8080/api/users"; // API endpoint for user signup
            const { data: res } = await axios.post(url, data); // Send POST request to signup user

            // Redirect user to login page upon successful signup
            navigate("/login");
            console.log(res.message); // Log success message to console
        } catch (error) {
            // Handle errors during signup process
            if (
                error.response &&
                error.response.status >= 400 &&
                error.response.status <= 500
            ) {
                // Set error message if response status is in the range of 400-500
                setError(error.response.data.message);
            }
        }
    };

    // Render the Signup form
    return (
        <div className={styles.signup_container}>
            <div className={styles.signup_form_container}>
                <div className={styles.left}>
                    <h1>Welcome Back</h1>
                    {/* Link to redirect user to login page */}
                    <Link to="/login">
                        <button type="button" className={styles.white_btn}>
                            Sing in
                        </button>
                    </Link>
                </div>
                <div className={styles.right}>
                    {/* Signup form */}
                    <form className={styles.form_container} onSubmit={handleSubmit}>
                        <h1>Create Account</h1>
                        {/* Input fields for user details */}
                        <input
                            type="text"
                            placeholder="First Name"
                            name="firstName"
                            onChange={handleChange}
                            value={data.firstName}
                            required
                            className={styles.input}
                        />
                        <input
                            type="text"
                            placeholder="Last Name"
                            name="lastName"
                            onChange={handleChange}
                            value={data.lastName}
                            required
                            className={styles.input}
                        />
                        <input
                            type="email"
                            placeholder="Email"
                            name="email"
                            onChange={handleChange}
                            value={data.email}
                            required
                            className={styles.input}
                        />
                        <input
                            type="password"
                            placeholder="Password"
                            name="password"
                            onChange={handleChange}
                            value={data.password}
                            required
                            className={styles.input}
                        />
                        {/* Display error message if any */}
                        {error && <div className={styles.error_msg}>{error}</div>}
                        {/* Submit button */}
                        <button type="submit" className={styles.green_btn}>
                            Sing Up
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

// Export the Signup component
export default Signup;
