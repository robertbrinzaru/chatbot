import axios from "axios";

const API = {
  GetChatbotResponse: async message => {
    return new Promise(async function (resolve, reject) {
      
      try {
        const url = "http://localhost:8080/api/chat/getmessage";
        const { data: res } = await axios.post(url, {message});
        
        if(res) {
          if (message === "hi") resolve("Welcome to chatbot!");
          else resolve("echo : " + res?.message);
        }
      } catch (error) {

      }
    });
  }
};

export default API;
