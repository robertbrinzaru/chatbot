import React, { useState } from "react"; // Import React and useState hook
import styles from "./chatbot.module.css"; // Import CSS module for styling

// Define the Input component
export default function Input({ onSend }) {
    // State variable to store the input text
    const [text, setText] = useState("");

    // Event handler to update the input text as the user types
    const handleInputChange = e => {
        setText(e.target.value);
    };

    // Event handler to send the message when the form is submitted
    const handleSend = e => {
        e.preventDefault(); // Prevent default form submission behavior
        if(text === '') {
            return alert("please enter message")
        } else {
            onSend(text); // Call the onSend function with the input text
            setText(""); // Clear the input text after sending
        }
        
    };

    // Render the Input component
    return (
        <div className={styles.input}>
            {/* Form for sending messages */}
            <form onSubmit={handleSend}>
                {/* Input field for typing the message */}
                <input
                    type="text"
                    onChange={handleInputChange}
                    value={text}
                    placeholder="Enter your message here"
                />
                {/* Button to submit the message */}
                <button>
                    {/* SVG icon for the send button */}
                    <svg
                        version="1.1"
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 500 500"
                    >
                        <g>
                            <g>
                                <polygon points="0,497.25 535.5,267.75 0,38.25 0,216.75 382.5,267.75 0,318.75" />
                            </g>
                        </g>
                    </svg>
                </button>
            </form>
        </div>
    );
}
