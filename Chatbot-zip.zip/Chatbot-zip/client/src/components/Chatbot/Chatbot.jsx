import React, { useState, useEffect } from "react"; // Import necessary hooks from React
import BotMessage from "./BotMessage"; // Import BotMessage component
import UserMessage from "./UserMessage"; // Import UserMessage component
import Messages from "./Messages"; // Import Messages component
import Input from "./Input"; // Import Input component
import API from "./ChatbotAPI"; // Import ChatbotAPI module
import styles from "./chatbot.module.css"; // Import CSS module for styling
import Header from "./Header"; // Import Header component

// Define the Chatbot component
const Chatbot = () => {
    // State variable to store chat messages
    const [messages, setMessages] = useState([]);

    // useEffect hook to load welcome message on component mount
    useEffect(() => {
        // Function to load the welcome message
        async function loadWelcomeMessage() {
            // Set the welcome message as the initial message in the chat
            setMessages([
                <BotMessage
                    key="0"
                    fetchMessage={async () => await API.GetChatbotResponse("hi")}
                />
            ]);
        }
        // Call the loadWelcomeMessage function when the component mounts
        loadWelcomeMessage();
    }, []);

    // Function to send a user message and receive a response from the chatbot
    const send = async text => {
        // Construct new messages array with user message and bot response
        const newMessages = messages.concat(
            <UserMessage key={messages.length + 1} text={text} />,
            <BotMessage
                key={messages.length + 2}
                fetchMessage={async () => await API.GetChatbotResponse(text)}
            />
        );
        // Update the messages state with the new messages array
        setMessages(newMessages);
    };

    // Render the Chatbot component
    return (
        <div className={styles.chatbot}>
            {/* Render the header */}
            <Header />
            {/* Render the chat messages */}
            <Messages messages={messages} />
            {/* Render the input component for sending messages */}
            <Input onSend={send} />
        </div>
    );
}

// Export the Chatbot component
export default Chatbot;
