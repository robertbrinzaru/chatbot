import React, { useState, useEffect } from "react"; // Import necessary hooks from React
import styles from "./chatbot.module.css"; // Import CSS module for styling

// Define the BotMessage component
export default function BotMessage({ fetchMessage }) {
    // State variables for loading state and message content
    const [isLoading, setLoading] = useState(true);
    const [message, setMessage] = useState("");

    // useEffect hook to fetch message on component mount
    useEffect(() => {
        // Function to load message from the server
        async function loadMessage() {
            // Fetch message using the provided fetchMessage function
            const msg = await fetchMessage();
            // Update loading state and message content
            setLoading(false);
            setMessage(msg);
        }
        // Call the loadMessage function when the component mounts
        loadMessage();
    }, [fetchMessage]); // useEffect dependency on fetchMessage function

    // Render the BotMessage component
    return (
        <div className={styles.message_container}>
            {/* Render the bot message, displaying loading indicator while loading */}
            <div className={styles.bot_message}>{isLoading ? "..." : message}</div>
        </div>
    );
}
