import Chatbot from "../Chatbot/Chatbot";
import AppHeader from "../Header/AppHeader";
import styles from "./styles.module.css";

const Main = () => {
	return (
		<div className={styles.main_container}>
			<AppHeader/>
			<div>
				<Chatbot/>
			</div>
		</div>
	);
};

export default Main;
