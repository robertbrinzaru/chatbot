import React from 'react'
import styles from './styles.module.css'
const PageNotFound = () => {
  return (
    <div className={styles.not_found_wrapper}>
      <div className={styles.not_found_container}>
        <h1 className={styles.not_found_heading}>404 - Page Not Found</h1>
        <p className={styles.not_found_text}>The page you are looking for does not exist.</p>
      </div>
    </div>
  )
}

export default PageNotFound
