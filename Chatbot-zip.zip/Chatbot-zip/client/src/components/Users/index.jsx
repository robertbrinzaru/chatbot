import React, { useEffect, useState } from 'react';
import styles from './styles.module.css'; // Import CSS file for styling
import AppHeader from '../Header/AppHeader';
import axios from "axios";

function Users() {
  const [data, setData] = useState([]);

  const handleRoleChange = async (id, newRole) => {
    try {
      // Make an API call to update the user's role
      const response = await axios.put(`http://localhost:8080/api/users/${id}/changerole`, { admin: newRole });
      if (response?.data?.message === "User role changed successfully") {
        // Update the state with the updated user data
        setData(prevData =>
          prevData.map(user =>
            user._id === id ? { ...user, admin: newRole } : user
          )
        );
      }


    } catch (error) {
      console.error('Error updating role:', error);
      // Handle error if necessary
    }
  };

  useEffect(() => {
    // Fetch users data from the server when the component mounts
    axios.get('http://localhost:8080/api/users/getusers')
      .then((res) => setData(res.data))
      .catch(error => {
        console.error('Error fetching users:', error);
        // Handle error if necessary
      });
  }, []);

  return (
    <div>
      <AppHeader />
      <p className={styles.main_text}>Users</p>
      <div className={styles.table_container}>
        <table className={styles.user_table}>
          <thead>
            <tr>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {data.map(user => (
              <tr key={user._id}>
                <td>{user.firstName}</td>
                <td>{user.lastName}</td>
                <td>{user.email}</td>
                <td>{user.admin ? 'Admin' : 'User'}</td>
                <td style={{ textAlign: 'center' }}>
                  <button onClick={() => handleRoleChange(user._id, !user.admin)}>
                    Change Role
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Users;
