import React, { useEffect, useState } from 'react';
import styles from './styles.module.css'; // Import CSS file for styling
import AppHeader from '../Header/AppHeader';
import axios from 'axios';

function Upload() {
    const [fileData, setFileData] = useState([])
    const handleUpload = async () => {
        // Handle upload functionality here
        const url = "http://localhost:8080/api/chat/setfiledata";
        const { data: res } = await axios.post(url, {fileData});
        if(res.success){
            alert('Data has been uploaded successfully!')
        }
    };

    useEffect(() => {
        // Fetch users data from the server when the component mounts
        axios.get('http://localhost:8080/api/chat/getfiledata')
            .then((res) => setFileData(res.data?.fileData))
            .catch(error => {
                console.error('Error fetching users:', error);
                // Handle error if necessary
            });
    }, []);
    return (
        <div>
            <AppHeader />
            <div className={styles.upload_container}>
                <textarea type="text" value={fileData} onChange={(e) => setFileData(e.target.value)} className={styles.upload_input} placeholder="Enter text..." />
                <div className={styles.btn_wrapper}>
                    <button className={styles.upload_button} onClick={handleUpload}>Upload</button>
                </div>
            </div>
        </div>
    );
}

export default Upload;
