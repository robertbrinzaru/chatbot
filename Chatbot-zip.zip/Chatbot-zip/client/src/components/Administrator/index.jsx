import React from 'react';
import styles from './styles.module.css'; // Import CSS file for styling
import AppHeader from '../Header/AppHeader';
import { useNavigate } from 'react-router-dom';

const Administrator = () => {
    const navigate = useNavigate()
    return (
        <div>
            <AppHeader />
            <h2 className={styles.adminText}>Administrator</h2>
            <div className={styles.container}>
                <div className={styles.box} onClick={() => navigate('/upload')}>
                    <h2>Upload</h2>
                </div>
                <div className={styles.box} onClick={() => navigate('/users')}>
                    <h2>Users</h2>
                </div>
            </div>
        </div>
    );
};

export default Administrator;
