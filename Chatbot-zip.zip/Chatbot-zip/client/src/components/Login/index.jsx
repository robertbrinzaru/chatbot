// Import necessary hooks and modules
import { useState } from "react"; // useState hook for state management
import axios from "axios"; // Axios for making HTTP requests
import { Link, Navigate } from "react-router-dom"; // Link and Navigate for navigation
import styles from "./styles.module.css"; // CSS module for styling

// Define the Login component
const Login = () => {
    // State variables for form data and error message
    const [data, setData] = useState({ email: "", password: "" });
    const [error, setError] = useState(""); // State variable for error message

    // Event handler to update state when input values change
    const handleChange = ({ currentTarget: input }) => {
        setData({ ...data, [input.name]: input.value });
    };

    // Event handler to submit the form data
    const handleSubmit = async (e) => {
        e.preventDefault(); // Prevent default form submission behavior
        try {
            const url = "http://localhost:8080/api/auth"; // API endpoint for user authentication
            const { data: res } = await axios.post(url, data); // Send POST request to authenticate user

            // Store user data in localStorage upon successful login
            localStorage.setItem("user", JSON.stringify(res.data));

            // Redirect user based on their role (admin or regular user)
            if (res.data?.user?.admin) {
                window.location = "/admin"; // Redirect to admin dashboard if user is an admin
            } else {
                window.location = "/"; // Redirect to main application if user is a regular user
            }
        } catch (error) {
            // Handle errors during login process
            if (
                error.response &&
                error.response.status >= 400 &&
                error.response.status <= 500
            ) {
                // Set error message if response status is in the range of 400-500
                setError(error.response.data.message);
            }
        }
    };

    // Render the Login form
    return (
        <div className={styles.login_container}>
            <div className={styles.login_form_container}>
                <div className={styles.left}>
                    {/* Login form */}
                    <form className={styles.form_container} onSubmit={handleSubmit}>
                        <h1>Login to Your Account</h1>
                        {/* Input fields for email and password */}
                        <input
                            type="email"
                            placeholder="Email"
                            name="email"
                            onChange={handleChange}
                            value={data.email}
                            required
                            className={styles.input}
                        />
                        <input
                            type="password"
                            placeholder="Password"
                            name="password"
                            onChange={handleChange}
                            value={data.password}
                            required
                            className={styles.input}
                        />
                        {/* Display error message if any */}
                        {error && <div className={styles.error_msg}>{error}</div>}
                        {/* Submit button */}
                        <button type="submit" className={styles.green_btn}>
                            Sing In
                        </button>
                    </form>
                </div>
                <div className={styles.right}>
                    <h1>New Here ?</h1>
                    {/* Link to redirect user to signup page */}
                    <Link to="/signup">
                        <button type="button" className={styles.white_btn}>
                            Sing Up
                        </button>
                    </Link>
                </div>
            </div>
        </div>
    );
};

// Export the Login component
export default Login;