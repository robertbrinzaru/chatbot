import { Outlet, Navigate } from 'react-router-dom'

const AdminProtectedRoute = () => {
    const user = JSON.parse(localStorage.getItem('user'))
    return(
        user?.token ? user?.user?.admin ? <Outlet/> : <Navigate to="/"/> : <Navigate to="/login"/>
    )
}

export default AdminProtectedRoute