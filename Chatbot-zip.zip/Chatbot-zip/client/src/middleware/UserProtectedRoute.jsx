import { Outlet, Navigate, useLocation } from 'react-router-dom'

const UserProtectedRoute = () => {
    const user = JSON.parse(localStorage.getItem('user'))
    const location = useLocation();
    console.log(location,'k')
    return(
        user?.token ? !user?.user?.admin ? <Outlet/> : <Navigate to="/admin"/> : <Navigate to="/login"/>
    )
}

export default UserProtectedRoute