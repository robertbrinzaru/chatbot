// Import necessary components and functions from react-router-dom
import { Route, Routes, BrowserRouter, Navigate } from "react-router-dom";
import Main from "./components/Main";
import Signup from "./components/Singup";
import Login from "./components/Login";
import Administrator from "./components/Administrator";
import Users from "./components/Users";
import Upload from "./components/Upload";
import PageNotFound from "./components/PageNotFound";
import AdminProtectedRoute from "./middleware/AdminProtectedRoute";
import UserProtectedRoute from "./middleware/UserProtectedRoute";

// Define the main App component
function App() {
    // Retrieve user data from localStorage and parse it
    const user = JSON.parse(localStorage.getItem('user'));

    return (
        // Wrap the routes with BrowserRouter to enable routing
        <BrowserRouter>
            {/* Define the routes */}
            <Routes>
                {/* Route for sign-up page */}
                {/* Redirect to home page if user is already logged in */}
                {
                    user ? <Route path="/signup" element={<Navigate replace to="/" />} /> : <Route path="/signup" element={<Signup />} />
                }
                {/* Route for login page */}
                {/* Redirect to home page if user is already logged in */}
                {
                    user ? <Route path="/login" element={<Navigate replace to="/" />} /> : <Route path="/login" element={<Login />} />
                }
                {/* Protected routes for admin */}
                <Route element={<AdminProtectedRoute />}>
                    {/* Route for admin dashboard */}
                    <Route path="/admin" element={<Administrator />} />
                    {/* Route for managing users */}
                    <Route path="/users" element={<Users />} />
                    {/* Route for file upload */}
                    <Route path="/upload" element={<Upload />} />
                </Route>
                {/* Protected routes for regular users */}
                <Route element={<UserProtectedRoute />}>
                    {/* Route for the main application */}
                    <Route path="/" exact element={<Main />} />
                </Route>
                {/* Route for handling invalid paths */}
                <Route path="*" element={<PageNotFound />} />
            </Routes>
        </BrowserRouter>
    );
}

// Export the App component as the default export
export default App;
